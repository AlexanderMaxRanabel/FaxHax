package dev.fiki.forgehax.api.events.game;

public class PreGameTickEvent extends GameTickEvent {
}
