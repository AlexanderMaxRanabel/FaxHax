package dev.fiki.forgehax.api.events.render;

import dev.fiki.forgehax.api.event.Cancelable;
import dev.fiki.forgehax.api.event.Event;

@Cancelable
public class BlockOverlayRenderEvent extends Event {
}
