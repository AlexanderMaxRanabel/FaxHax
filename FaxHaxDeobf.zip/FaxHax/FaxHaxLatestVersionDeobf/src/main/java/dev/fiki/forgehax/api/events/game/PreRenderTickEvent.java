package dev.fiki.forgehax.api.events.game;

import dev.fiki.forgehax.api.event.Event;

public class PreRenderTickEvent extends Event {
}
