package dev.fiki.forgehax.main.mods.render;

import dev.fiki.forgehax.api.mod.ToggleMod;

// TODO: 1.15 might have changed
//@RegisterMod(
//    name = "NoSkylightUpdates",
//    description = "Prevents skylight updates",
//    category = Category.RENDER
//)
public class NoSkylightUpdates extends ToggleMod {
//  public void onLightingUpdate(WorldCheckLightForEvent event) {
//
//    if (event.getEnumSkyBlock() == EnumSkyBlock.SKY) {
//      event.setCanceled(true);
//    }
//  }
}
