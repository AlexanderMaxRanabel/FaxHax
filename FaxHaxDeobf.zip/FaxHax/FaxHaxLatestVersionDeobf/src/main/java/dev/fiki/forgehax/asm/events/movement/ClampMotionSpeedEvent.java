package dev.fiki.forgehax.asm.events.movement;

import dev.fiki.forgehax.api.event.Cancelable;
import dev.fiki.forgehax.api.event.Event;

@Cancelable
public class ClampMotionSpeedEvent extends Event {
}
