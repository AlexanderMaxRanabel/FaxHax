package dev.fiki.forgehax.api.events;

import dev.fiki.forgehax.api.event.Event;

public class ConnectToServerEvent extends Event {
}
