package dev.fiki.forgehax.api.cmd.listener;

public class Listeners {
  public static IOnUpdate onUpdate(IOnUpdate o) {
    return o;
  }
}
