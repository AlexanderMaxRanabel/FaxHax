package dev.fiki.forgehax.api.asm.runtime;

public enum Format {
  NORMAL,
  SRG,
  OBFUSCATED
}
