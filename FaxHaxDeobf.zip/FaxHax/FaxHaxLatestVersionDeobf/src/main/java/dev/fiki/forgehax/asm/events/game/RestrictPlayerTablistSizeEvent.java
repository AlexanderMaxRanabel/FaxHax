package dev.fiki.forgehax.asm.events.game;

import dev.fiki.forgehax.api.event.Cancelable;
import dev.fiki.forgehax.api.event.Event;

@Cancelable
public class RestrictPlayerTablistSizeEvent extends Event {
}
