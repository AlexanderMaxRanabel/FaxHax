package dev.fiki.forgehax.main.mods.player;

import dev.fiki.forgehax.api.mod.ToggleMod;
import lombok.RequiredArgsConstructor;

//@RegisterMod(
//    name = "AntiAFK",
//    description = "Swing arm to prevent being afk kicked",
//    category = Category.PLAYER
//)
@RequiredArgsConstructor
public class AntiAFK extends ToggleMod {
  // TODO: make a better anti afk
}
