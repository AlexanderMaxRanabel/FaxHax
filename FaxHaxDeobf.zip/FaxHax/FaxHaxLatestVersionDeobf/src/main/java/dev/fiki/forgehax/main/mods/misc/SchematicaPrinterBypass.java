package dev.fiki.forgehax.main.mods.misc;

import dev.fiki.forgehax.api.mod.ToggleMod;

//@RegisterMod(
//    name = "PrinterBypass",
//    description = "Set silent angles for schematica printer",
//    category = Category.MISC
//)
public class SchematicaPrinterBypass extends ToggleMod {
//  @SubscribeEvent
//  public void onPrinterBlockPlace(SchematicaPlaceBlockEvent event) {
//    final BlockPos pos = event.getPos().offset(event.getSide());
//    final Vector3d vec = new Vector3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
//
//    Angle lookAngle = Utils.getLookAtAngles(vec);
//    Globals.sendNetworkPacket(new CPlayerPacket.RotationPacket(lookAngle.getYaw(),
//        lookAngle.getPitch(), Globals.getLocalPlayer().onGround));
//  }
  // TODO: 1.15
}
