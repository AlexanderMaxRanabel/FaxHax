package dev.fiki.forgehax.api.common;

/**
 * Created on 6/8/2017 by fr1kin
 */
public enum PriorityEnum {
  HIGHEST,
  HIGH,
  DEFAULT,
  LOW,
  LOWEST,
  ;
}
