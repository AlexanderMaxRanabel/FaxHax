package dev.fiki.forgehax.api.events.game;

public class PostGameTickEvent extends GameTickEvent {
}
