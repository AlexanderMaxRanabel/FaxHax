package dev.fiki.forgehax.mapper.type;

public enum MappedFormat {
  MAPPED,
  OBFUSCATED,
  SRG;
}
