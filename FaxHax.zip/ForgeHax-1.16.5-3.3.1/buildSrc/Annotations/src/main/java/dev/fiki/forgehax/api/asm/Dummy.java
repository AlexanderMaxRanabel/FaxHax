package dev.fiki.forgehax.api.asm;

interface Dummy {
}
