package dev.fiki.forgehax.mapper.extractor

interface Importer {
  void read(MapData data)
}
