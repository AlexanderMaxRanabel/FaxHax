package dev.fiki.forgehax.asm.events.render;

import dev.fiki.forgehax.api.event.Cancelable;
import dev.fiki.forgehax.api.event.Event;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Cancelable
public class HurtCamEffectEvent extends Event {
}
